﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Renderer.cs" company="OxyPlot">
//   Copyright (c) 2020 OxyPlot contributors
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace ExampleBrowser
{
    public enum Renderer
    {
        Canvas,
        Canvas_XAML,
        SkiaSharp
    }
}
